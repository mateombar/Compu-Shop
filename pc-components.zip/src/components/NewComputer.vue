<template>
  <div id="new-computer">
    <h3>New Computer</h3>
  </div>
</template>

<script>
export default {
  name: 'new-computer',
  data() {
    return {}
  }
}
</script>
