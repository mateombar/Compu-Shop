export default{
    apiKey: "AIzaSyDVuHymr-vF4xGEFrZoaU36uD_cU-Ke72o",
    authDomain: "pc-building-389ad.firebaseapp.com",
    databaseURL: "https://pc-building-389ad.firebaseio.com",
    projectId: "pc-building-389ad",
    storageBucket: "pc-building-389ad.appspot.com",
    messagingSenderId: "670922267945",
    appId: "1:670922267945:web:e22b97ff7c4765b365eb38",
    measurementId: "G-0EW2BHLXS7"
}