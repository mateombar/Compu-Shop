<template>
  <div id="edit-computer">
    <h3>Edit Computer</h3>
  </div>
</template>

<script>
export default {
  name: 'edit-computer',
  data() {
    return {}
  }
}
</script>
