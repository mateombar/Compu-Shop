<template>
  <div id="view-computer">
    <h3>Computer</h3>
  </div>
</template>

<script>
export default {
  name: 'view-computer',
  data() {
    return {}
  }
}
</script>
